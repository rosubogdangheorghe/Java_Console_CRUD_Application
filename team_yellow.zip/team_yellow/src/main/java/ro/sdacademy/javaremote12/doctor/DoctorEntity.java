package ro.sdacademy.javaremote12.doctor;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "doctors")
public class DoctorEntity {

}
