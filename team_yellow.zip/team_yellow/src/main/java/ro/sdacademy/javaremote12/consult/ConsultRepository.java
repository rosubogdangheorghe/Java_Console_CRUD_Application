package ro.sdacademy.javaremote12.consult;

import ro.sdacademy.javaremote12.doctor.DoctorEntity;
import ro.sdacademy.javaremote12.patient.PatientEntity;

import java.time.LocalDate;
import java.util.List;

public interface ConsultRepository {

    void createConsult(ConsultEntity consult);
    void updateConsult(Integer id, Double price, String diagnostic);
    List<ConsultEntity> getAllConsults();
    ConsultEntity getConsultById(Integer Id);
    void deleteConsult(Integer id);

}
