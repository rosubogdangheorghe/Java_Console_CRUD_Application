package ro.sdacademy.javaremote12;

public class Application {

    public void start(){

    }
}
