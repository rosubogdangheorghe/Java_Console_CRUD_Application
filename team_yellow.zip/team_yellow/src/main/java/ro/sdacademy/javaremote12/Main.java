package ro.sdacademy.javaremote12;

public class Main {

    //One window for CRUD operations on Doctor
    // (firstname, lastname, address, speciality): allows the viewing of all the vets;
    // adding a new vet; deleting an existing vet and updating an existing vet
    //One window for CRUD operations on Patient (race, birthdate, isVaccinated, ownerName):
    // allows the viewing of all the pets; adding a new pet; deleting an existing
    // pet and updating an existing pet
    //One window for Consult (veterinarian, pet, date, description):
    // allows the viewing of all the consults; adding a new consult
    // for an existing vet and an existing pet; updating the description of a consult
    public static void main(String[] args) {
	// write your code here
        System.out.println("text");
    }
}
