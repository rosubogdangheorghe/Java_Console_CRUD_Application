package ro.sdacademy.javaremote12.patient;

import javax.persistence.Entity;
import javax.persistence.Table;
import java.time.LocalDate;

@Entity
@Table(name= "patients")
public class PatientEntity {

    private String name;
    private Integer age;
    private LocalDate birthday;

    public PatientEntity(String name, Integer age, LocalDate birthday) {
        this.name = name;
        this.birthday = birthday;
        this.age = ageComputation(birthday);
    }

    public PatientEntity(Integer age) {
        this.age = age;
    }
    public Integer ageComputation(LocalDate birthday) {

        Integer year = birthday.getYear();
        Integer age = LocalDate.now().getYear() - year;
        return age;

    }
}
